import {createServer} from 'node:http';
import {performance} from 'node:perf_hooks';
import {fetchWithTimeout} from '../../src/data/request-timeout.ts';
import {startServer} from '../../src/server/index.ts';
import {mkdtempSync,writeFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
const results={};
const slow=createServer((_req,res)=>{res.writeHead(200,{'Content-Type':'application/json'});res.flushHeaders();setTimeout(()=>res.end('{"ok":true}'),150);});
await new Promise(done=>slow.listen(0,'127.0.0.1',done));
let at=performance.now();
const response=await fetchWithTimeout(`http://127.0.0.1:${slow.address().port}`,{},80);
results.timeoutHeadersMs=performance.now()-at;
await response.json();
results.timeoutBodyMs=performance.now()-at;
results.timeoutLimitMs=80;
await new Promise(done=>slow.close(done));
const directory=mkdtempSync(resolve('work/audit-2026-09-12/multi-'));
process.env.PUBLIC_ORIGIN='https://audit.invalid';
process.env.INITIAL_ADMIN_YANDEX_ID='audit-admin';
process.env.YANDEX_CLIENT_ID='synthetic';process.env.YANDEX_CLIENT_SECRET='synthetic';
const mock=async u=>new Response(JSON.stringify(String(u).includes('/token')?{access_token:'synthetic'}:{id:'audit-admin'}));
const a=await startServer(0,join(directory,'drevo.sqlite'),true,mock);
const b=await startServer(0,join(directory,'drevo.sqlite'),true,mock);
try {
  const baseA=`http://127.0.0.1:${a.server.address().port}`,baseB=`http://127.0.0.1:${b.server.address().port}`;
  const start=await fetch(baseA+'/auth/yandex',{redirect:'manual'});
  const state=new URL(start.headers.get('location')).searchParams.get('state');
  const req={redirect:'manual',headers:{Cookie:start.headers.getSetCookie()[0].split(';')[0]}};
  results.twoInstances={healthA:(await fetch(baseA+'/api/health')).status,healthB:(await fetch(baseB+'/api/health')).status,callbackOther:(await fetch(baseB+`/auth/yandex/callback?code=synthetic&state=${state}`,req)).status,callbackOriginal:(await fetch(baseA+`/auth/yandex/callback?code=synthetic&state=${state}`,req)).status};
}finally{await b.close();await a.close();}
const root=await fetch('https://drevo.kiiko.ru/',{signal:AbortSignal.timeout(15000)});
const html=await root.text();
const asset=/src="(\/assets\/[^\"]+\.js)"/.exec(html)?.[1];
results.production={root:root.status,rootHeaders:Object.fromEntries(root.headers),asset};
if(asset){const head=await fetch('https://drevo.kiiko.ru'+asset,{method:'HEAD',headers:{'Accept-Encoding':'gzip, br'},signal:AbortSignal.timeout(15000)});results.production.assetHeaders=Object.fromEntries(head.headers);}
writeFileSync('work/audit-2026-09-12/extra-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));
