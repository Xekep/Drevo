import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve,dirname,extname,relative} from 'node:path';
import ts from 'typescript';
const git=(args,input)=>execFileSync('git',args,{encoding:'utf8',input,maxBuffer:256*1024*1024});
const files=git(['ls-files']).trim().split('\n');
const textFiles=files.filter(p=>/\.(ts|tsx|mjs|css|md|html|json|yml|sh|conf|service)$/.test(p));
const stats={files:files.length,textFiles:textFiles.length,lines:0,sourceLines:0,tests:[],docs:[],todos:[],lockOrigins:{},cycles:[],history:{},secretCandidates:[]};
const rules=[['private-key',/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g],['github-token',/\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,})\b/g],['aws-key',/\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g],['openai-key',/\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}\b/g],['literal-credential',/(?:YANDEX_CLIENT_SECRET|ARCHIVE_PASSWORD|SESSION_SECRET|DATABASE_URL)\s*[:=]\s*["']([^"'\s]{12,})["']/g]];
function scan(text,path,hash){for(const [name,pattern] of rules){pattern.lastIndex=0;for(const m of text.matchAll(pattern)){stats.secretCandidates.push({path,hash,rule:name,line:text.slice(0,m.index).split('\n').length});}}}
const graph=new Map();
for(const path of textFiles){const text=readFileSync(path,'utf8');stats.lines+=text.split('\n').length;if(path.startsWith('src/'))stats.sourceLines+=text.split('\n').length;if(path.startsWith('docs/'))stats.docs.push({path,headings:text.split('\n').filter(l=>/^#{1,3} /.test(l))});if(path.startsWith('tests/'))stats.tests.push({path,testCount:(text.match(/\btest\(/g)||[]).length,sourceAssertions:/readFileSync|readFile\(/.test(text)});text.split('\n').forEach((l,i)=>{if(/\b(TODO|FIXME|HACK)\b/.test(l))stats.todos.push({path,line:i+1});});scan(text,path,'HEAD');if(/\.tsx?$/.test(path)&&path.startsWith('src/')){const source=ts.createSourceFile(path,text,ts.ScriptTarget.Latest,true);const deps=[];for(const node of source.statements){if((ts.isImportDeclaration(node)||ts.isExportDeclaration(node))&&node.moduleSpecifier&&ts.isStringLiteral(node.moduleSpecifier)){if(node.importClause?.isTypeOnly||node.isTypeOnly)continue;const spec=node.moduleSpecifier.text;if(!spec.startsWith('.'))continue;const base=resolve(dirname(path),spec);const target=[base,base+'.ts',base+'.tsx',resolve(base,'index.ts')].find(existsSync);if(target)deps.push(relative('.',target).replaceAll('\\','/'));}}graph.set(path,deps);}}
const done=new Set(),active=[];
function walk(p){if(active.includes(p)){stats.cycles.push([...active.slice(active.indexOf(p)),p]);return;}if(done.has(p))return;active.push(p);for(const d of graph.get(p)||[])walk(d);active.pop();done.add(p);}for(const p of graph.keys())walk(p);
for(const file of ['package-lock.json','ops/runtime/package-lock.json']){const lock=JSON.parse(readFileSync(file,'utf8'));const origins={};for(const pkg of Object.values(lock.packages)){if(pkg.resolved){let origin;try{origin=new URL(pkg.resolved).origin;}catch{origin=pkg.resolved.split(':')[0];}origins[origin]=(origins[origin]||0)+1;}}stats.lockOrigins[file]=origins;}
const objectLines=git(['rev-list','--objects','--all']).trim().split('\n');
const objects=objectLines.map(l=>{const i=l.indexOf(' ');return {hash:l.slice(0,i),path:l.slice(i+1)};}).filter(x=>/\.(ts|tsx|mjs|css|md|html|json|yml|sh|conf|service|env|pem|key)$|(^|\/)\.env/.test(x.path));
let scanned=0,bytes=0;
for(const obj of objects){let body;try{body=git(['cat-file','blob',obj.hash]);}catch{continue;}if(body.includes('\0'))continue;scan(body,obj.path,obj.hash);scanned++;bytes+=Buffer.byteLength(body);}
stats.history={commits:Number(git(['rev-list','--count','--all'])),blobsScanned:scanned,textBytes:bytes,scope:'Locally reachable history only; pattern scan, not entropy/Gitleaks'};
writeFileSync('work/audit-2026-09-12/inventory.json',JSON.stringify(stats,null,2));
console.log(JSON.stringify({...stats,docs:stats.docs.map(d=>d.path),tests:{files:stats.tests.length,totalNamed:stats.tests.reduce((n,t)=>n+t.testCount,0),usingSourceReads:stats.tests.filter(t=>t.sourceAssertions).map(t=>t.path)}},null,2));
