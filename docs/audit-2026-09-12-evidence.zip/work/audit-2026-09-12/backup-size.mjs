import {startServer} from '../../src/server/index.ts';
import {writeDatabaseBackup} from '../../src/server/backup.ts';
import {mkdtempSync,statSync,readFileSync,writeFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
const directory=mkdtempSync(resolve('work/audit-2026-09-12/backup-size-'));
delete process.env.PUBLIC_ORIGIN;process.env.NODE_ENV='test';
const app=await startServer(0,join(directory,'drevo.sqlite'),true);
try {
  const family={title:'Synthetic backup benchmark',description:'',demo:false,people:Array.from({length:10000},(_,i)=>({id:'p'+i,name:'Person',surname:'Synthetic'+i,patronymic:'',sex:'u',birth:'',birthPlace:'',parents:i?['p'+Math.floor((i-1)/2)]:[],spouses:[],sources:[],biography:'b'.repeat(512),generation:1,column:0})),photos:[]};
  app.archive.write(family,app.archive.meta().revision);
  for(let i=0;i<6;i++){const state=app.archive.read();state.family.people[0].name='Backup size test'+i;app.archive.write(state.family,state.revision);}
  const backup=join(directory,'export.sqlite');writeDatabaseBackup(app.archive.db,backup);
  const base=`http://127.0.0.1:${app.server.address().port}`;
  const r=await fetch(base+'/api/restore/preview',{method:'POST',headers:{Origin:base,'X-Drevo-Restore':'1'},body:readFileSync(backup)});
  const result={bytes:statSync(backup).size,people:app.archive.read().family.people.length,status:r.status,response:await r.json()};
  writeFileSync('work/audit-2026-09-12/backup-size-results.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}finally{await app.close();}
