import {writeFileSync} from 'node:fs';
const r=await fetch('https://drevo.kiiko.ru/assets/index-CSbGT7Ip.js',{headers:{'Accept-Encoding':'gzip, br'},signal:AbortSignal.timeout(15000)});
const b=await r.arrayBuffer();
const result={status:r.status,headers:Object.fromEntries(r.headers),decodedBytes:b.byteLength};
writeFileSync('work/audit-2026-09-12/production-asset.json',JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
