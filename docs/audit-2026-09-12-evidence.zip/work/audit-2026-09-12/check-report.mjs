import {readFileSync,existsSync} from 'node:fs';
const text=readFileSync('docs/audit-2026-09-12.md','utf8');
const issues=[...text.matchAll(/^### \[(A\d+)\] (.+)$/gm)].map(m=>({id:m[1],title:m[2],at:m.index}));
const missing=[];
for(const match of text.matchAll(/`((?:src|tests|docs|ops|\.github)\/[^`\s]+):(\d+)`/g)){
 const path=match[1],line=Number(match[2]);
 if(!existsSync(path))missing.push({path,line,error:'missing file'});
 else if(readFileSync(path,'utf8').split('\n').length<line)missing.push({path,line,error:'line past EOF'});
}
const labels=['Категория:','Severity:','Priority:','Confidence:','Где:','Что происходит:','Почему это проблема:','При каких условиях проявится:','Последствия:','Как воспроизвести:','Как исправить:','Сложность исправления:'];
const format=[];
for(let i=0;i<issues.length;i++){
 const section=text.slice(issues[i].at,issues[i+1]?.at??text.length);
 for(const label of labels) if(!section.includes(label))format.push({id:issues[i].id,missing:label});
}
console.log(JSON.stringify({bytes:Buffer.byteLength(text),lines:text.split('\n').length,issues:issues.length,uniqueIDs:new Set(issues.map(x=>x.id)).size,missing,format,titles:issues.map(({id,title})=>({id,title}))},null,2));
if(missing.length||format.length||issues.length!==new Set(issues.map(x=>x.id)).size)process.exitCode=1;
