import { startServer } from '../../src/server/index.ts';
import { performance } from 'node:perf_hooks';
import { cpus, totalmem } from 'node:os';
import { mkdtempSync, writeFileSync, statSync } from 'node:fs';
import { resolve, join } from 'node:path';
const directory=mkdtempSync(resolve('work/audit-2026-09-12/bench-'));
process.env.PUBLIC_ORIGIN='https://audit.invalid';
process.env.INITIAL_ADMIN_YANDEX_ID='benchmark-admin';
delete process.env.ARCHIVE_PRIVATE;
const report={environment:{node:process.version,platform:process.platform,cpu:cpus()[0].model,logicalCPUs:cpus().length,ramGiB:totalmem()/2**30},cases:[]};
const round=n=>Math.round(n*100)/100;
for(const n of [1000,10000]) {
  const app=await startServer(0,join(directory,`db-${n}`,'drevo.sqlite'),true);
  const base=`http://127.0.0.1:${app.server.address().port}`;
  try {
    let family={title:'Synthetic benchmark',description:'',demo:false,people:Array.from({length:n},(_,i)=>({id:'p'+i,name:'Person',surname:'Synthetic'+i,patronymic:'',sex:'u',birth:'',birthPlace:'',parents:i?['p'+Math.floor((i-1)/2)]:[],spouses:[],sources:[],biography:'b'.repeat(512),generation:1,column:0})),photos:[]};
    const seedAt=performance.now();app.archive.write(family,app.archive.meta().revision);
    const item={people:n,seedMs:round(performance.now()-seedAt),http:[],writes:[]};
    const full=app.archive.read();
    item.fullJsonBytes=Buffer.byteLength(JSON.stringify(full));
    for(const [name,fn] of [['meta',()=>app.archive.meta()],['overview',()=>app.archive.overview()],['read',()=>app.archive.read()],['page0',()=>app.archive.peoplePage(0,40)],['pageLast',()=>app.archive.peoplePage(n-40,40)]]) {
      const times=[];for(let i=0;i<5;i++){const at=performance.now();fn();times.push(performance.now()-at);}
      item[name+'MedianMs']=round(times.sort((a,b)=>a-b)[2]);
    }
    for(let i=0;i<3;i++){const state=app.archive.read();state.family.people[0].name='Edit'+i;const at=performance.now();app.archive.write(state.family,state.revision);item.writes.push(round(performance.now()-at));}
    for(const concurrency of [1,10,...(n===1000?[100]:[])]) {
      const times=[],at=performance.now();let bytes=0;
      await Promise.all(Array.from({length:concurrency},async()=>{const t=performance.now();const r=await fetch(base+'/api/family?projection=overview');const b=await r.arrayBuffer();bytes+=b.byteLength;if(r.status!==200)throw new Error('Bad status');times.push(performance.now()-t);}));
      times.sort((a,b)=>a-b);
      item.http.push({concurrency,requests:times.length,wallMs:round(performance.now()-at),p50Ms:round(times[Math.floor(times.length*.5)]),p95Ms:round(times[Math.min(times.length-1,Math.floor(times.length*.95))]),bytes});
    }
    item.historyBytes=app.archive.db.prepare('SELECT sum(length(data)) AS n FROM history').get().n;
    item.rssMiB=round(process.memoryUsage().rss/2**20);
    report.cases.push(item);
  }finally{await app.close();}
}
writeFileSync(join(directory,'results.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({directory,...report},null,2));
